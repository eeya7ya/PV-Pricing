import { type SolarProject, type InsertSolarProject, type CalculationResults, type MonthlyConsumption, type TimeFactors, type User, type InsertUser, type UpsertUser, users, TARIFF_PRESETS } from "@shared/schema";
import { randomUUID } from "crypto";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db } from "./db";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

const MemoryStore = createMemoryStore(session);

// Solar PV Calculator Storage Interface
export interface IStorage {
  // Solar Projects
  getSolarProject(id: string): Promise<SolarProject | undefined>;
  getSolarProjectByName(name: string): Promise<SolarProject | undefined>;
  createSolarProject(project: InsertSolarProject): Promise<SolarProject>;
  updateSolarProject(id: string, project: Partial<InsertSolarProject>): Promise<SolarProject | undefined>;
  deleteSolarProject(id: string): Promise<boolean>;
  getAllSolarProjects(): Promise<SolarProject[]>;
  
  // Calculation Storage
  saveCalculationResults(projectId: string, results: CalculationResults): Promise<void>;
  getCalculationResults(projectId: string): Promise<CalculationResults | undefined>;
  
  // User Authentication - Updated for OAuth integration
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByOidcSub(oidcSub: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  upsertUser(userData: UpsertUser): Promise<User>;
  
  // Database Seeding
  seedDefaultUsers(): Promise<void>;
  
  // Session Store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private solarProjects: Map<string, SolarProject>;
  private calculationResults: Map<string, CalculationResults>;
  public sessionStore: session.Store;

  constructor() {
    this.solarProjects = new Map();
    this.calculationResults = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  async getSolarProject(id: string): Promise<SolarProject | undefined> {
    return this.solarProjects.get(id);
  }

  async getSolarProjectByName(name: string): Promise<SolarProject | undefined> {
    return Array.from(this.solarProjects.values()).find(
      (project) => project.name === name,
    );
  }

  async createSolarProject(insertProject: InsertSolarProject): Promise<SolarProject> {
    const id = randomUUID();
    const now = new Date().toISOString();
    
    // Default tariff configuration based on customer type
    const customerType = insertProject.customer_type ?? 'Residential';
    const defaultTariffType = customerType === 'Industrial' ? 'industrial:tou' : 'residential:tiered';
    const defaultTariffConfig = TARIFF_PRESETS[defaultTariffType];
    
    const project: SolarProject = { 
      id, 
      created_at: now,
      updated_at: now,
      name: insertProject.name,
      customer_type: customerType,
      grid_connection: insertProject.grid_connection ?? 'Net billing',
      consumption_data: insertProject.consumption_data,
      efficiency: insertProject.efficiency ?? 95,
      degradation: insertProject.degradation ?? 0.5,
      tariff_supported: insertProject.tariff_supported ?? true,
      export_tariff: insertProject.export_tariff ?? 0.05,
      day_factors: insertProject.day_factors,
      evening_factors: insertProject.evening_factors,
      night_factors: insertProject.night_factors,
      sun_peak_factors: insertProject.sun_peak_factors,
      sun_medium_factors: insertProject.sun_medium_factors,
      sun_low_factors: insertProject.sun_low_factors,
      pv_consume_day: insertProject.pv_consume_day,
      pv_consume_evening: insertProject.pv_consume_evening,
      pv_consume_night: insertProject.pv_consume_night,
      calculation_results: insertProject.calculation_results,
      // New tariff configuration fields
      tariff_type: insertProject.tariff_type ?? defaultTariffType,
      tariff_config: insertProject.tariff_config ?? defaultTariffConfig
    };
    this.solarProjects.set(id, project);
    return project;
  }

  async updateSolarProject(id: string, updateData: Partial<InsertSolarProject>): Promise<SolarProject | undefined> {
    const existingProject = this.solarProjects.get(id);
    if (!existingProject) {
      return undefined;
    }
    
    const updatedProject: SolarProject = {
      ...existingProject,
      ...updateData,
      updated_at: new Date().toISOString()
    };
    
    this.solarProjects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteSolarProject(id: string): Promise<boolean> {
    const deleted = this.solarProjects.delete(id);
    if (deleted) {
      this.calculationResults.delete(id);
    }
    return deleted;
  }

  async getAllSolarProjects(): Promise<SolarProject[]> {
    return Array.from(this.solarProjects.values());
  }

  async saveCalculationResults(projectId: string, results: CalculationResults): Promise<void> {
    this.calculationResults.set(projectId, results);
    
    // Also update the project with the results
    const project = this.solarProjects.get(projectId);
    if (project) {
      project.calculation_results = results as any;
      project.updated_at = new Date().toISOString();
    }
  }

  async getCalculationResults(projectId: string): Promise<CalculationResults | undefined> {
    return this.calculationResults.get(projectId);
  }

  // User Authentication Methods - OAuth Integration Support
  async getUser(id: string): Promise<User | undefined> {
    // Convert string ID to number since database uses serial integer IDs
    const numericId = parseInt(id, 10);
    if (isNaN(numericId)) {
      return undefined;
    }
    const result = await db.select().from(users).where(eq(users.id, numericId)).limit(1);
    return result[0] || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0] || undefined;
  }

  async getUserByOidcSub(oidcSub: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.oidcSub, oidcSub)).limit(1);
    return result[0] || undefined;
  }

  // Required for Replit Auth integration - upserts user from OAuth claims
  async upsertUser(userData: UpsertUser): Promise<User> {
    // First try to find user by oidcSub
    if (userData.oidcSub) {
      const existingUser = await this.getUserByOidcSub(userData.oidcSub);
      if (existingUser) {
        // Update existing user profile from OAuth claims
        const result = await db
          .update(users)
          .set({
            ...userData,
            email: userData.email?.toLowerCase(),
            updatedAt: new Date(),
          })
          .where(eq(users.oidcSub, userData.oidcSub))
          .returning();
        return result[0];
      }
    }

    // If no user found by oidcSub but email is provided and verified, 
    // check if there's an existing user with this email to link accounts
    if (userData.email) {
      const normalizedEmail = userData.email.toLowerCase();
      const existingEmailUser = await db
        .select()
        .from(users)
        .where(eq(users.email, normalizedEmail))
        .limit(1);
      
      if (existingEmailUser[0]) {
        // Link the existing email account with this OAuth provider
        const result = await db
          .update(users)
          .set({
            oidcSub: userData.oidcSub,
            firstName: userData.firstName || existingEmailUser[0].firstName,
            lastName: userData.lastName || existingEmailUser[0].lastName,
            profileImageUrl: userData.profileImageUrl || existingEmailUser[0].profileImageUrl,
            updatedAt: new Date(),
          })
          .where(eq(users.email, normalizedEmail))
          .returning();
        return result[0];
      }
    }

    // Create new user if no existing user found
    const newUserData = {
      ...userData,
      email: userData.email?.toLowerCase(),
    };
    
    const result = await db.insert(users).values(newUserData).returning();
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async seedDefaultUsers(): Promise<void> {
    try {
      // Check if any users exist
      const existingUsers = await db.select().from(users).limit(1);
      
      if (existingUsers.length === 0) {
        // Create default admin user
        const adminPassword = await bcrypt.hash('admin123', 10);
        await db.insert(users).values({
          username: 'admin',
          password: adminPassword,
          isAdmin: true
        });

        // Create default regular user  
        const userPassword = await bcrypt.hash('user123', 10);
        await db.insert(users).values({
          username: 'user',
          password: userPassword,
          isAdmin: false
        });

        console.log('✅ Default users created successfully:');
        console.log('   Admin: admin/admin123');
        console.log('   User: user/user123');
      }
    } catch (error) {
      console.error('❌ Failed to seed default users:', error);
    }
  }
}

export const storage = new MemStorage();