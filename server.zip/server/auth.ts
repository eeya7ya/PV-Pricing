import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, insertUserSchema } from "@shared/schema";
import { z } from "zod";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Initialize default admin user (only in development)
async function initializeDefaultAdmin() {
  // Only create default admin in development or when explicitly enabled
  if (process.env.NODE_ENV === 'production' && !process.env.CREATE_DEFAULT_ADMIN) {
    return;
  }
  
  try {
    const existingAdmin = await storage.getUserByUsername('admin');
    if (!existingAdmin) {
      // Use environment password if provided, otherwise fallback to development default
      const adminPassword = process.env.ADMIN_PASSWORD || 
        (process.env.NODE_ENV === 'development' ? 'admin123' : undefined);
      
      if (!adminPassword) {
        console.error('ADMIN_PASSWORD environment variable required for default admin creation');
        return;
      }
      
      const hashedPassword = await hashPassword(adminPassword);
      await storage.createUser({
        username: 'admin',
        password: hashedPassword,
        isAdmin: true
      });
      console.log('Created default admin user (username: admin)');
    }
  } catch (error) {
    console.error('Error creating default admin user:', error);
  }
}

export function setupAuth(app: Express) {
  // Validate required environment variables
  if (!process.env.SESSION_SECRET) {
    throw new Error('SESSION_SECRET environment variable is required');
  }
  
  // Initialize default admin user
  initializeDefaultAdmin();
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET!,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      const user = await storage.getUserByUsername(username);
      if (!user || !(await comparePasswords(password, user.password))) {
        return done(null, false);
      } else {
        return done(null, user);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    const user = await storage.getUser(id);
    done(null, user);
  });

  // LOGIN ONLY - No public registration
  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });

  // ADMIN ONLY - Create new user (only for admins)
  app.post("/api/admin/create-user", async (req, res, next) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(403).send("Admin access required");
    }

    try {
      // Validate request body with Zod
      const createUserSchema = insertUserSchema.omit({ id: true }).extend({
        password: z.string().min(8, "Password must be at least 8 characters"),
      });
      
      const validatedData = createUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).send("Username already exists");
      }

      const user = await storage.createUser({
        username: validatedData.username,
        password: await hashPassword(validatedData.password),
        isAdmin: validatedData.isAdmin ?? false,
      });

      res.status(201).json({ username: user.username, id: user.id, isAdmin: user.isAdmin });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Validation error", details: error.errors });
      }
      next(error);
    }
  });
}

export { hashPassword };