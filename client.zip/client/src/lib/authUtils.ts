// Auth utilities for Replit Auth integration - handles error checking
export function isUnauthorizedError(error: Error): boolean {
  return /^401: .*Unauthorized/.test(error.message);
}